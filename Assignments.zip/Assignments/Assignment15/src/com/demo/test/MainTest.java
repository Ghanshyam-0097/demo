package com.demo.test;
import com.demo.beans.*;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

public class MainTest {
    public static void main(String[] args) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("productdata.dat"))) {
            List<Product> list = new ArrayList<>();
            list.add(new Product(101, "Shoes", 2, 2500));
            list.add(new Product(102, "Shirt", 1, 1500));
            list.add(new Product(103, "Watch", 3, 1200));
            oos.writeObject(list);
        } catch (Exception e) {
            e.printStackTrace();
        }

        
        SharedBuffer buffer = new SharedBuffer();
        Producer producer = new Producer(buffer);
        Consumer consumer = new Consumer(buffer);
        producer.start();
        consumer.start();
    }
}

