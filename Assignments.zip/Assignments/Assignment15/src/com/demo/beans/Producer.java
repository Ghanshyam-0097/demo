package com.demo.beans;

import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.List;

public class Producer extends Thread {
    private SharedBuffer buffer;

    public Producer(SharedBuffer buffer) {
        this.buffer = buffer;
    }

    public void run() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("productdata.dat"))) {
            List<Product> products = (List<Product>) ois.readObject();
            for (Product p : products) {
                buffer.produce(p);
                Thread.sleep(100); // simulate delay
            }
            buffer.produce(null); // end signal
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

