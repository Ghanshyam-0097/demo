package com.demo.beans;

public class SharedBuffer {
    Product product;
    boolean available = false;

    public synchronized void produce(Product p) {
        while (available) {
            try { wait(); } catch (InterruptedException e) { e.printStackTrace(); }
        }
        product = p;
        available = true;
        notify();
    }

    public synchronized Product consume() {
        while (!available) {
            try { wait(); } catch (InterruptedException e) { e.printStackTrace(); }
        }
        available = false;
        notify();
        return product;
    }
}
