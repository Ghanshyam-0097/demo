package com.demo.beans;

import java.io.FileWriter;
import java.io.PrintWriter;

public class Consumer extends Thread {
    private SharedBuffer buffer;

    public Consumer(SharedBuffer buffer) {
        this.buffer = buffer;
    }

    public void run() {
        try (PrintWriter pw = new PrintWriter(new FileWriter("productamount.dat"))) {
            Product p;
            while ((p = buffer.consume()) != null) {
                double amount = (p.getQty() * p.getPrice()) + (0.10 * p.getPrice());
                pw.println(p.getId() + ":" + p.getName() + ":" + p.getQty() + ":" + p.getPrice() + ":" + amount);
                Thread.sleep(100); // simulate delay
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

