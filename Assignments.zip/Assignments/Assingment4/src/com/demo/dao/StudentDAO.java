package com.demo.dao;

import com.demo.*;
import com.demo.beans.Student;

import java.util.Set;

public interface StudentDAO {
    void addStudent(Student student);
    void addSkill(int sid, String skill);
    void deleteStudent(int sid);
    void deleteSkill(int sid, String skill);
    Set<Student> getStudentsBySkill(String skill);
    Set<Student> getStudentsByDegree(String degree);
    Set<Student> getAllStudents();
}