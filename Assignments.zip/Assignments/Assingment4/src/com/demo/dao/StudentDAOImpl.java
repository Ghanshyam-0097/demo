package com.demo.dao;

import com.demo.beans.*;

import java.util.*;

public class StudentDAOImpl implements StudentDAO {
    private Map<Student, Set<String>> studentMap = new HashMap<>();

    public void addStudent(Student student) {
        studentMap.putIfAbsent(student, new HashSet<>());
    }

    public void addSkill(int sid, String skill) {
        for (Student student : studentMap.keySet()) {
            if (student.getSid() == sid) {
                studentMap.get(student).add(skill);
                break;
            }
        }
    }

    public void deleteStudent(int sid) {
        studentMap.entrySet().removeIf(entry -> entry.getKey().getSid() == sid);
    }

    public void deleteSkill(int sid, String skill) {
        for (Student student : studentMap.keySet()) {
            if (student.getSid() == sid) {
                studentMap.get(student).remove(skill);
                break;
            }
        }
    }

    public Set<Student> getStudentsBySkill(String skill) {
        Set<Student> result = new HashSet<>();
        for (Map.Entry<Student, Set<String>> entry : studentMap.entrySet()) {
            if (entry.getValue().contains(skill)) {
                result.add(entry.getKey());
            }
        }
        return result;
    }

    public Set<Student> getStudentsByDegree(String degree) {
        Set<Student> result = new HashSet<>();
        for (Student student : studentMap.keySet()) {
            if (student.getDegree().equalsIgnoreCase(degree)) {
                result.add(student);
            }
        }
        return result;
    }

    public Set<Student> getAllStudents() {
        return studentMap.keySet();
    }
}