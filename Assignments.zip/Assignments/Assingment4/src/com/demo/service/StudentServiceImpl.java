package com.demo.service;

import com.demo.beans.*;
import com.demo.dao.*;

import java.util.Set;

public class StudentServiceImpl implements StudentService {
    private StudentDAO dao = new StudentDAOImpl();

    public void addStudent(Student student) {
        dao.addStudent(student);
    }

    public void addSkill(int sid, String skill) {
        dao.addSkill(sid, skill);
    }

    public void deleteStudent(int sid) {
        dao.deleteStudent(sid);
    }

    public void deleteSkill(int sid, String skill) {
        dao.deleteSkill(sid, skill);
    }

    public Set<Student> getStudentsBySkill(String skill) {
        return dao.getStudentsBySkill(skill);
    }

    public Set<Student> getStudentsByDegree(String degree) {
        return dao.getStudentsByDegree(degree);
    }

    public Set<Student> getAllStudents() {
        return dao.getAllStudents();
    }
}