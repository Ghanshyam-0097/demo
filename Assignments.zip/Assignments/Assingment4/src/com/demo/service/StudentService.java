package com.demo.service;

import com.demo.beans.*;
import java.util.Set;

public interface StudentService {
    void addStudent(Student student);
    void addSkill(int sid, String skill);
    void deleteStudent(int sid);
    void deleteSkill(int sid, String skill);
    Set<Student> getStudentsBySkill(String skill);
    Set<Student> getStudentsByDegree(String degree);
    Set<Student> getAllStudents();
}