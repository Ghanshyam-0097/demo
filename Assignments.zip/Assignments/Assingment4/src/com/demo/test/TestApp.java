package com.demo.test;

import com.demo.beans.*;
import com.demo.service.*;

import java.time.LocalDate;
import java.util.Scanner;

public class TestApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StudentService service = new StudentServiceImpl();
        int choice;

        do {
            System.out.println("\n--- ABC Recruitment Student Skill Manager ---");
            System.out.println("1. Add New Student");
            System.out.println("2. Add New Skill for a Student");
            System.out.println("3. Delete Student");
            System.out.println("4. Delete Skill for a Student");
            System.out.println("5. Display Students by Skill");
            System.out.println("6. Display Students by Degree");
            System.out.println("7. Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1 -> {
                    System.out.print("Enter Student ID: ");
                    int sid = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter DOB (yyyy-mm-dd): ");
                    LocalDate bdate = LocalDate.parse(sc.nextLine());
                    System.out.print("Enter Degree: ");
                    String degree = sc.nextLine();
                    System.out.print("Enter Marks: ");
                    double marks = sc.nextDouble();
                    service.addStudent(new Student(sid, name, bdate, degree, marks));
                }
                case 2 -> {
                    System.out.print("Enter Student ID: ");
                    int sid = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Skill: ");
                    String skill = sc.nextLine();
                    service.addSkill(sid, skill);
                }
                case 3 -> {
                    System.out.print("Enter Student ID to delete: ");
                    int sid = sc.nextInt();
                    service.deleteStudent(sid);
                }
                case 4 -> {
                    System.out.print("Enter Student ID: ");
                    int sid = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Skill to delete: ");
                    String skill = sc.nextLine();
                    service.deleteSkill(sid, skill);
                }
                case 5 -> {
                    System.out.print("Enter Skill: ");
                    String skill = sc.nextLine();
                    service.getStudentsBySkill(skill).forEach(System.out::println);
                }
                case 6 -> {
                    System.out.print("Enter Degree: ");
                    String degree = sc.nextLine();
                    service.getStudentsByDegree(degree).forEach(System.out::println);
                }
                case 7 -> System.out.println("Exiting...");
                default -> System.out.println("Invalid choice.");
            }
        } while (choice != 7);
    }
}