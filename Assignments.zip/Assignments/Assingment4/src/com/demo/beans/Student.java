package com.demo.beans;

import java.time.LocalDate;
import java.util.Objects;

public class Student {
    private int sid;
    private String name;
    private LocalDate bdate;
    private String degree;
    private double marks;

    public Student(int sid, String name, LocalDate bdate, String degree, double marks) {
        this.sid = sid;
        this.name = name;
        this.bdate = bdate;
        this.degree = degree;
        this.marks = marks;
    }

    public int getSid() { return sid; }
    public String getName() { return name; }
    public LocalDate getBdate() { return bdate; }
    public String getDegree() { return degree; }
    public double getMarks() { return marks; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Student)) return false;
        Student student = (Student) o;
        return sid == student.sid;
    }

    @Override
    public int hashCode() {
        return Objects.hash(sid);
    }

    @Override
    public String toString() {
        return "SID: " + sid + ", Name: " + name + ", DOB: " + bdate + ", Degree: " + degree + ", Marks: " + marks;
    }
}