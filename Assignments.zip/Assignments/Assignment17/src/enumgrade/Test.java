package enumgrade;

import java.util.Scanner;

public class Test {
	 public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter grade (Distinction, First, Second, Pass, Fail):");
	        String input = sc.nextLine();

	        try {
	            Grade g = Grade.valueOf(input);
	            System.out.println("Grade: " + g);
	            System.out.println("Minimum Marks: " + g.getMinMarks());
	            System.out.println("Maximum Marks: " + g.getMaxMarks());
	        } catch (IllegalArgumentException e) {
	            System.out.println("Invalid grade entered.");
	        }

	        sc.close();
	    }
}
