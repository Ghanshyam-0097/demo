package enumgrade;

import java.util.Scanner;

enum Grade {
    Distinction(80, 100),
    First(65, 79),
    Second(50, 64),
    Pass(40, 49),
    Fail(0, 39);

    private final int minMarks;
    private final int maxMarks;

    Grade(int minMarks, int maxMarks) {
        this.minMarks = minMarks;
        this.maxMarks = maxMarks;
    }

    public int getMinMarks() {
        return minMarks;
    }

    public int getMaxMarks() {
        return maxMarks;
    }
}
