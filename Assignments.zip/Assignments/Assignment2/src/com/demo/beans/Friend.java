package com.demo.beans;
import java.util.List;

	public class Friend {
	    private int id;
	    private String name;
	    private String lastName;
	    private List<String> hobbies;
	    private String mobile;
	    private String email;
	    private String birthDate;
	    private String address;

	    public Friend(int id, String name, String lastName, List<String> hobbies, String mobile, String email, String birthDate, String address) {
	        this.id = id;
	        this.name = name;
	        this.lastName = lastName;
	        this.hobbies = hobbies;
	        this.mobile = mobile;
	        this.email = email;
	        this.birthDate = birthDate;
	        this.address = address;
	    }

	    public int getId() {
	        return id;
	    }

	    public String getName() {
	        return name;
	    }

	    public List<String> getHobbies() {
	        return hobbies;
	    }

	    @Override
	    public String toString() {
	        return "Friend ID: " + id + "\nName: " + name + " " + lastName +
	               "\nHobbies: " + hobbies +
	               "\nMobile: " + mobile + "\nEmail: " + email +
	               "\nBirth Date: " + birthDate + "\nAddress: " + address;
	    }
	}

