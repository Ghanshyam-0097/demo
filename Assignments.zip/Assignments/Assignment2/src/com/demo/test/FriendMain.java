package com.demo.test;


import java.util.Scanner;

import com.demo.service.FriendService;

public class FriendMain {
    public static void main(String[] args) {
        FriendService service = new FriendService();
        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n1. Add Friend");
            System.out.println("2. Display All Friends");
            System.out.println("3. Search by ID");
            System.out.println("4. Search by Name");
            System.out.println("5. Display Friends with a Particular Hobby");
            System.out.println("6. Exit");
            System.out.print("Choice: ");
            choice = sc.nextInt();
            sc.nextLine();  // consume newline

            switch (choice) {
                case 1 -> service.addFriend();
                case 2 -> service.displayAll();
                case 3 -> {
                    System.out.print("Enter ID: ");
                    int id = sc.nextInt();
                    service.searchById(id);
                }
                case 4 -> {
                    System.out.print("Enter name: ");
                    String name = sc.nextLine();
                    service.searchByName(name);
                }
                case 5 -> {
                    System.out.print("Enter hobby: ");
                    String hobby = sc.nextLine();
                    service.displayByHobby(hobby);
                }
                case 6 -> System.out.println("Exiting...");
                default -> System.out.println("Invalid choice.");
            }
        } while (choice != 6);
    }
}

