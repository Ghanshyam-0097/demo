package com.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.demo.beans.Friend;

public class FriendService {
    private List<Friend> friends = new ArrayList<>();
    private static int nextId = 1;
    private Scanner sc = new Scanner(System.in);

    public void addFriend() {
        System.out.print("Enter name: ");
        String name = sc.nextLine();
        System.out.print("Enter last name: ");
        String lastName = sc.nextLine();
        System.out.print("Enter hobbies: ");
        List<String> hobbies = List.of(sc.nextLine().split(","));
        System.out.print("Enter mobile: ");
        String mobile = sc.nextLine();
        System.out.print("Enter email: ");
        String email = sc.nextLine();
        System.out.print("Enter birth date: ");
        String bdate = sc.nextLine();
        System.out.print("Enter address: ");
        String address = sc.nextLine();

        friends.add(new Friend(nextId++, name, lastName, hobbies, mobile, email, bdate, address));
    }

    public void displayAll() {
        friends.forEach(System.out::println);
    }

    public void searchById(int id) {
        friends.stream().filter(f -> f.getId() == id).forEach(System.out::println);
    }

    public void searchByName(String name) {
        friends.stream().filter(f -> f.getName().equalsIgnoreCase(name)).forEach(System.out::println);
    }

    public void displayByHobby(String hobby) {
        friends.stream().filter(f -> f.getHobbies().contains(hobby)).forEach(System.out::println);
    }
}

