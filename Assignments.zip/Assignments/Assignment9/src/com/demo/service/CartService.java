package com.demo.service;

import com.demo.model.Product;

import java.util.*;

public class CartService {
    private static List<Product> productList = new ArrayList<>();
    private static Map<String, List<Product>> userCarts = new HashMap<>();

    static {
        productList.add(new Product(1, "Shoes", 3000, 10));
        productList.add(new Product(2, "Shirts", 1500, 15));
        productList.add(new Product(3, "Bags", 2000, 8));
        productList.add(new Product(4, "Watches", 2500, 5));
        productList.add(new Product(5, "Glasses", 1200, 20));
        productList.add(new Product(6, "Jeans", 1800, 10));
        productList.add(new Product(7, "Hats", 600, 25));
        productList.add(new Product(8, "Belts", 500, 18));
        productList.add(new Product(9, "Jackets", 3500, 6));
        productList.add(new Product(10, "T-shirts", 800, 20));
    }

    public void showAllProducts() {
        for (Product p : productList) {
            System.out.println(p);
        }
    }

    public void buyProduct(String username, int productId, int qty) {
        for (Product p : productList) {
            if (p.getId() == productId) {
                if (p.getQty() >= qty) {
                    double total = p.getPrice() * qty;
                    System.out.println("Amount = " + total + "/-");

                    Product boughtProduct = new Product(p.getId(), p.getName(), p.getPrice(), qty);
                    userCarts.computeIfAbsent(username, k -> new ArrayList<>()).add(boughtProduct);
                    p.setQty(p.getQty() - qty);
                } else {
                    System.out.println("Not enough quantity in stock.");
                }
                return;
            }
        }
        System.out.println("Product ID not found.");
    }

    public void showUsers() {
        if (userCarts.isEmpty()) {
            System.out.println("No users have carts yet.");
            return;
        }

        System.out.println("Users with carts:");
        for (String username : userCarts.keySet()) {
            System.out.println("- " + username);
        }
    }

    public void displayBill(String username) {
        if (!userCarts.containsKey(username)) {
            System.out.println("No cart found for this user.");
            return;
        }

        List<Product> cart = userCarts.get(username);
        double total = 0;
        System.out.println("Cart for user: " + username);
        for (Product p : cart) {
            double amt = p.getPrice() * p.getQty();
            System.out.println(p.getName() + " x " + p.getQty() + " = " + amt + "/-");
            total += amt;
        }
        System.out.println("Total Bill = " + total + "/-");
    }

    public void deliverCart(String username) {
        if (userCarts.containsKey(username)) {
            userCarts.remove(username);
            System.out.println("Order delivered and cart cleared.");
        } else {
            System.out.println("No cart found for this user.");
        }
    }
}

