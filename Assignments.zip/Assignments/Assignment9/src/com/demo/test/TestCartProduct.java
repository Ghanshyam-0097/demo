package com.demo.test;

import com.demo.service.CartService;

import java.util.Scanner;

public class TestCartProduct {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        CartService service = new CartService();

        while (true) {
            System.out.println("\n--- MENU ---");
            System.out.println("1. Buy Products");
            System.out.println("2. Send the delivery of cart");
            System.out.println("3. Exit");
            System.out.print("Enter choice: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    sc.nextLine(); // consume newline
                    System.out.print("Enter username: ");
                    String username = sc.nextLine();

                    System.out.println("Available Products:");
                    service.showAllProducts();

                    System.out.print("Enter product ID to buy: ");
                    int pid = sc.nextInt();

                    System.out.print("Enter quantity: ");
                    int qty = sc.nextInt();

                    service.buyProduct(username, pid, qty);
                    break;

                case 2:
                    service.showUsers();
                    sc.nextLine(); // consume newline
                    System.out.print("Enter username to deliver cart: ");
                    String user = sc.nextLine();

                    service.displayBill(user);

                    System.out.print("Do you want to deliver the cart? (y/n): ");
                    String deliver = sc.nextLine().toLowerCase();

                    if (deliver.equals("y")) {
                        service.deliverCart(user);
                    }
                    break;

                case 3:
                    System.out.println("Exiting program. Thank you!");
                    sc.close();
                    return;

                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
}

