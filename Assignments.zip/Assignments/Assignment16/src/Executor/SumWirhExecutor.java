package Executor;
import java.util.concurrent.*;
import java.util.*;

public class SumWirhExecutor {
	 public static void main(String[] args) throws InterruptedException, ExecutionException {
	        ExecutorService executor = Executors.newFixedThreadPool(5);
	        List<Future<Integer>> futures = new ArrayList<>();

	        // Create 51 numbers
	        List<Integer> numbers = new ArrayList<>();
	        for (int i = 1; i <= 51; i++) {
	            numbers.add(i);
	        }

	        // Submit tasks, each task takes 3 numbers
	        for (int i = 0; i < numbers.size(); i += 3) {
	            int a = numbers.get(i);
	            int b = (i + 1 < numbers.size()) ? numbers.get(i + 1) : 0;
	            int c = (i + 2 < numbers.size()) ? numbers.get(i + 2) : 0;
	            futures.add(executor.submit(new AddTask(a, b, c)));
	        }

	        // Get results from futures
	        int totalSum = 0;
	        for (Future<Integer> future : futures) {
	            totalSum += future.get();
	        }

	        System.out.println("Total sum of 51 numbers: " + totalSum);

	        executor.shutdown();
	    }
}
