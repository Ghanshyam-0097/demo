package services;

import entities.CityTrees;

import java.util.*;

public class CityTreesManager {
    private TreeMap<String, CityTrees> cityTreesMap;

    public CityTreesManager() {
        this.cityTreesMap = new TreeMap<>();
    }

    public void addCity(String cityName, List<String> trees) {
        cityTreesMap.putIfAbsent(cityName, new CityTrees(cityName));
        CityTrees cityTrees = cityTreesMap.get(cityName);
        for (String tree : trees) {
            cityTrees.addTree(tree.trim());
        }
    }

    public List<String> getTreesForCity(String cityName) {
        CityTrees cityTrees = cityTreesMap.get(cityName);
        return (cityTrees != null) ? cityTrees.getTrees() : null;
    }

    public void deleteCity(String cityName) {
        cityTreesMap.remove(cityName);
    }

    public void addTreeToCity(String cityName, String tree) {
        CityTrees cityTrees = cityTreesMap.get(cityName);
        if (cityTrees != null) {
            cityTrees.addTree(tree);
        }
    }

    public List<String> findCitiesWithTree(String tree) {
        List<String> cities = new ArrayList<>();
        for (CityTrees cityTrees : cityTreesMap.values()) {
            if (cityTrees.getTrees().contains(tree)) {
                cities.add(cityTrees.getCityName());
            }
        }
        return cities;
    }

    public void displayAllCitiesAndTrees() {
        // Using Iterator
        Iterator<Map.Entry<String, CityTrees>> iterator = cityTreesMap.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, CityTrees> entry = iterator.next();
            System.out.println("City: " + entry.getKey() + ", Trees: " + entry.getValue().getTrees());
        }

        // Using for-each loop
        for (Map.Entry<String, CityTrees> entry : cityTreesMap.entrySet()) {
            System.out.println("City: " + entry.getKey() + ", Trees: " + entry.getValue().getTrees());
        }
    }
}
