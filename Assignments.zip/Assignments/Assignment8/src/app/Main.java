package app;

import services.CityTreesManager;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        CityTreesManager manager = new CityTreesManager();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Add new city and its trees");
            System.out.println("2. Find list of trees for a city");
            System.out.println("3. Delete list of a particular city");
            System.out.println("4. Display all city names and list of trees");
            System.out.println("5. Add a new tree to an existing city");
            System.out.println("6. Find all cities with a specific tree");
            System.out.println("7. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter city name: ");
                    String city = scanner.nextLine();
                    System.out.print("Enter trees (comma separated): ");
                    String treesInput = scanner.nextLine();
                    List<String> trees = Arrays.asList(treesInput.split(","));
                    manager.addCity(city, trees);
                    break;
                case 2:
                    System.out.print("Enter city name: ");
                    city = scanner.nextLine();
                    List<String> cityTrees = manager.getTreesForCity(city);
                    if (cityTrees != null) {
                        System.out.println("Trees in " + city + ": " + cityTrees);
                    } else {
                        System.out.println("City not found.");
                    }
                    break;
                case 3:
                    System.out.print("Enter city name to delete: ");
                    city = scanner.nextLine();
                    manager.deleteCity(city);
                    System.out.println("City deleted.");
                    break;
                case 4:
                    manager.displayAllCitiesAndTrees();
                    break;
                case 5:
                    System.out.print("Enter city name: ");
                    city = scanner.nextLine();
                    System.out.print("Enter tree name to add: ");
                    String tree = scanner.nextLine();
                    manager.addTreeToCity(city, tree);
                    break;
                case 6:
                    System.out.print("Enter tree name to search: ");
                    tree = scanner.nextLine();
                    List<String> cities = manager.findCitiesWithTree(tree);
                    if (!cities.isEmpty()) {
                        System.out.println("Tree found in: " + cities);
                    } else {
                        System.out.println("No cities found with that tree.");
                    }
                    break;
                case 7:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
}
