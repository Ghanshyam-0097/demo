package entities;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class CityTrees {
    private String cityName;
    private List<String> trees;

    public CityTrees(String cityName) {
        this.cityName = cityName;
        this.trees = new ArrayList<>();
    }

    public String getCityName() {
        return cityName;
    }

    public List<String> getTrees() {
        return trees;
    }

    public void addTree(String tree) {
        if (!trees.contains(tree)) {
            trees.add(tree);
        }
    }

    public void removeTree(String tree) {
        trees.remove(tree);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CityTrees)) return false;
        CityTrees cityTrees = (CityTrees) o;
        return Objects.equals(cityName, cityTrees.cityName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(cityName);
    }
}
