package objectstream;

import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.ArrayList;


public class objectinputstream  {
    public static void main(String[] args) {
        ArrayList<Student> studentList = null;

        // Read the student list from students.dat using ObjectInputStream
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("students.dat"))) {
            studentList = (ArrayList<Student>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error reading from file: " + e.getMessage());
        }

        // Display student information
        if (studentList != null) {
            System.out.println("Student Information:");
            for (Student s : studentList) {
                System.out.println(s);
            }
        } else {
            System.out.println("No student data found.");
        }
    }
}

