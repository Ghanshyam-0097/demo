package Hello;

	import java.util.Vector;
	import java.util.Enumeration;

	public class VectorWithEnumeration {
	    public static void main(String[] args) {
	        // Create a Vector to store Strings
	        Vector<String> names = new Vector<>();

	        
	        names.add("Ghanshyam");
	        names.add("saurav");
	        names.add("kiran");
	        names.add("sagar");
	        names.add("rahul");

	        
	        Enumeration<String> e = names.elements();

	        System.out.println("Elements in the Vector:");

	        while (e.hasMoreElements()) {
	            String name = e.nextElement();
	            System.out.println(name);
	        }
	    }
	}

