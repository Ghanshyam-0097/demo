package com.demo.dao;

import com.demo.beans.*;


import java.util.ArrayList;
import java.util.List;

public class TeamDAOImpl implements TeamDAO {
    private List<Team> teams = new ArrayList<>();

    public void addTeam(Team team) {
        teams.add(team);
    }

    public void deleteTeam(int teamId) {
        teams.removeIf(t -> t.getTeamId() == teamId);
    }

    public boolean deletePlayer(int playerId) {
        for (Team team : teams) {
            if (team.removePlayerById(playerId)) {
                return true;
            }
        }
        return false;
    }

    public List<Player> getAllBatsmen() {
        List<Player> result = new ArrayList<>();
        for (Team team : teams) {
            for (Player player : team.getPlayers()) {
                if (player.getSpeciality().equalsIgnoreCase("batsman")) {
                    result.add(player);
                }
            }
        }
        return result;
    }

    public List<Player> getPlayersBySpeciality(String speciality) {
        List<Player> result = new ArrayList<>();
        for (Team team : teams) {
            for (Player player : team.getPlayers()) {
                if (player.getSpeciality().equalsIgnoreCase(speciality)) {
                    result.add(player);
                }
            }
        }
        return result;
    }

    public boolean addPlayerToTeam(int teamId, Player player) {
        for (Team team : teams) {
            if (team.getTeamId() == teamId) {
                team.addPlayer(player);
                return true;
            }
        }
        return false;
    }

    public boolean modifyCoach(int teamId, String newCoach) {
        for (Team team : teams) {
            if (team.getTeamId() == teamId) {
                team.setCoachName(newCoach);
                return true;
            }
        }
        return false;
    }

    public List<Team> getAllTeams() {
        return teams;
    }
}