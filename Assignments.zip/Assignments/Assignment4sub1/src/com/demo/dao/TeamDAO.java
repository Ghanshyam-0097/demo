package com.demo.dao;

import com.demo.beans.*;

import java.util.List;

public interface TeamDAO {
    void addTeam(Team team);
    void deleteTeam(int teamId);
    boolean deletePlayer(int playerId);
    List<Player> getAllBatsmen();
    List<Player> getPlayersBySpeciality(String speciality);
    boolean addPlayerToTeam(int teamId, Player player);
    boolean modifyCoach(int teamId, String newCoach);
    List<Team> getAllTeams();
}