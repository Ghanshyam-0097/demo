package com.demo.test;

import com.demo.beans.*;

import com.demo.service.*;

import java.util.Scanner;

public class TestApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        TeamService service = new TeamServiceImpl();
        int choice;

        do {
            System.out.println("\n--- IPL Team Management ---");
            System.out.println("1. Add New Team");
            System.out.println("2. Delete a Team");
            System.out.println("3. Delete a Player from Team");
            System.out.println("4. Display All Batsmen");
            System.out.println("5. Display Players by Speciality");
            System.out.println("6. Add New Player in a Team");
            System.out.println("7. Modify Coach of a Team");
            System.out.println("8. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1 -> {
                    System.out.print("Enter Team ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Team Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Coach Name: ");
                    String coach = sc.nextLine();
                    service.addTeam(new Team(id, name, coach));
                }
                case 2 -> {
                    System.out.print("Enter Team ID to delete: ");
                    int id = sc.nextInt();
                    service.deleteTeam(id);
                }
                case 3 -> {
                    System.out.print("Enter Player ID to delete: ");
                    int id = sc.nextInt();
                    if (!service.deletePlayer(id)) System.out.println("Player not found.");
                }
                case 4 -> service.getAllBatsmen().forEach(System.out::println);
                case 5 -> {
                    System.out.print("Enter Speciality: ");
                    String spec = sc.nextLine();
                    service.getPlayersBySpeciality(spec).forEach(System.out::println);
                }
                case 6 -> {
                    System.out.print("Enter Team ID to add player: ");
                    int teamId = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Player ID: ");
                    int pid = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Player Name: ");
                    String pname = sc.nextLine();
                    System.out.print("Enter Player Speciality: ");
                    String spec = sc.nextLine();
                    if (!service.addPlayerToTeam(teamId, new Player(pid, pname, spec)))
                        System.out.println("Team not found.");
                }
                case 7 -> {
                    System.out.print("Enter Team ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter New Coach Name: ");
                    String coach = sc.nextLine();
                    if (!service.modifyCoach(id, coach)) System.out.println("Team not found.");
                }
                case 8 -> System.out.println("Exiting...");
                default -> System.out.println("Invalid choice.");
            }
        } while (choice != 8);
    }
}