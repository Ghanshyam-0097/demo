package com.demo.service;

import com.demo.dao.*;
import com.demo.beans.*;

import java.util.List;

public class TeamServiceImpl implements TeamService {
    private TeamDAO dao = new TeamDAOImpl();

    public void addTeam(Team team) {
        dao.addTeam(team);
    }

    public void deleteTeam(int teamId) {
        dao.deleteTeam(teamId);
    }

    public boolean deletePlayer(int playerId) {
        return dao.deletePlayer(playerId);
    }

    public List<Player> getAllBatsmen() {
        return dao.getAllBatsmen();
    }

    public List<Player> getPlayersBySpeciality(String speciality) {
        return dao.getPlayersBySpeciality(speciality);
    }

    public boolean addPlayerToTeam(int teamId, Player player) {
        return dao.addPlayerToTeam(teamId, player);
    }

    public boolean modifyCoach(int teamId, String newCoach) {
        return dao.modifyCoach(teamId, newCoach);
    }

    public List<Team> getAllTeams() {
        return dao.getAllTeams();
    }
}