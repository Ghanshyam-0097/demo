package com.demo.beans;

import java.util.ArrayList;
import java.util.List;

public class Team {
    private int teamId;
    private String teamName;
    private String coachName;
    private List<Player> players;

    public Team(int teamId, String teamName, String coachName) {
        this.teamId = teamId;
        this.teamName = teamName;
        this.coachName = coachName;
        this.players = new ArrayList<>();
    }

    public int getTeamId() { return teamId; }
    public String getTeamName() { return teamName; }
    public String getCoachName() { return coachName; }
    public void setCoachName(String coachName) { this.coachName = coachName; }
    public List<Player> getPlayers() { return players; }

    public void addPlayer(Player player) {
        players.add(player);
    }

    public boolean removePlayerById(int playerId) {
        return players.removeIf(p -> p.getPlayerId() == playerId);
    }

    @Override
    public String toString() {
        return "TeamID: " + teamId + ", Name: " + teamName + ", Coach: " + coachName + ", Players: " + players;
    }
}