package com.citytrees;

import java.util.*;

public class CityTreeManager {
    private TreeMap<String, List<String>> cityTreeMap;

    public CityTreeManager() {
        cityTreeMap = new TreeMap<>();
    }

    public void addCity(String city, List<String> trees) {
        cityTreeMap.put(city, trees);
    }

    public boolean cityExists(String city) {
        return cityTreeMap.containsKey(city);
    }

    public List<String> getTrees(String city) {
        return cityTreeMap.get(city);
    }

    public void deleteCity(String city) {
        if (cityTreeMap.remove(city) != null) {
            System.out.println("City removed.");
        } else {
            System.out.println("City not found.");
        }
    }

    public void displayAll() {
        System.out.println("\nCity and Trees List (using Iterator):");
        Iterator<Map.Entry<String, List<String>>> it = cityTreeMap.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, List<String>> entry = it.next();
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }

        System.out.println("\nCity and Trees List (using for-each):");
        for (Map.Entry<String, List<String>> entry : cityTreeMap.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }
}
