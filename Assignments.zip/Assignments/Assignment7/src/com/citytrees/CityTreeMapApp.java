package com.citytrees;

import java.util.*;

public class CityTreeMapApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        CityTreeManager manager = new CityTreeManager();
        int choice;

        do {
            System.out.println("\n1. Add new city and trees");
            System.out.println("2. Find trees for a city");
            System.out.println("3. Delete a city");
            System.out.println("4. Display all cities and trees");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter city name: ");
                    String city = scanner.nextLine();
                    if (manager.cityExists(city)) {
                        System.out.println("City already exists.");
                        break;
                    }
                    System.out.print("Enter tree names separated by commas: ");
                    String[] trees = scanner.nextLine().split(",");
                    List<String> treeList = new ArrayList<>();
                    for (String tree : trees) {
                        treeList.add(tree.trim());
                    }
                    manager.addCity(city, treeList);
                    break;
                case 2:
                    System.out.print("Enter city name to search: ");
                    city = scanner.nextLine();
                    List<String> result = manager.getTrees(city);
                    if (result != null) {
                        System.out.println("Trees in " + city + ": " + result);
                    } else {
                        System.out.println("City not found.");
                    }
                    break;
                case 3:
                    System.out.print("Enter city name to delete: ");
                    city = scanner.nextLine();
                    manager.deleteCity(city);
                    break;
                case 4:
                    manager.displayAll();
                    break;
                case 5:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } while (choice != 5);
    }
}
