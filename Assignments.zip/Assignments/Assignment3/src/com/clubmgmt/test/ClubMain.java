package com.clubmgmt.test;
import com.clubmgmt.service.MemberService;
import com.clubmgmt.service.MemberServiceImpl;

import com.clubmgmt.service.ClubService;
import com.clubmgmt.service.ClubServiceImpl;

import java.util.Scanner;

public class ClubMain {
    public static void main(String[] args) {
        ClubServiceImpl service = new ClubServiceImpl();
        MemberService memberService = new MemberServiceImpl();
        service.addDummyData();
        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("""
                \n1. Display Employees by Type
                2. Search by ID
                3. Search by Name
                4. Display All Employees
                5. Display Salary by Designation
                6. Display 5 Employees by Department
                7. Exit
                """);

            System.out.print("Enter choice: ");
            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1 -> {
                    System.out.print("Enter type (SalariedEmployee / ContractEmployee / Vendor): ");
                    String type = sc.nextLine();
                    service.displayByType(type);
                }
                case 2 -> {
                    System.out.print("Enter ID: ");
                    int id = sc.nextInt();
                    service.searchById(id);
                }
                case 3 -> {
                    System.out.print("Enter name: ");
                    String name = sc.nextLine();
                    service.searchByName(name);
                }
                case 4 -> service.displayAll();
                case 5 -> {
                    System.out.print("Enter designation: ");
                    String desig = sc.nextLine();
                    service.displayByDesignation(desig);
                }
                case 6 -> {
                    System.out.print("Enter department: ");
                    String dept = sc.nextLine();
                    service.displayByDepartment(dept);
                }
                case 7 -> System.out.println("Exiting...");
                default -> System.out.println("Invalid choice.");
            }
        } while (choice != 7);
    }
}
