package com.clubmgmt.dao;

import com.clubmgmt.model.Member;
import java.util.List;

public interface MemberDao {
    void addMember(Member m);
    List<Member> getAllMembers();
    Member getById(int id);
    List<Member> getByName(String name);
}

