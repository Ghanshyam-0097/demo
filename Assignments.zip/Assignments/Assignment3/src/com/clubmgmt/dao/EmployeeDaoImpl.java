package com.clubmgmt.dao;

import com.clubmgmt.model.Employee;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class EmployeeDaoImpl implements EmployeeDao {
    private List<Employee> employees = new ArrayList<>();

    @Override
    public void addEmployee(Employee e) {
        employees.add(e);
    }

    @Override
    public List<Employee> getAllEmployees() {
        return employees;
    }

    @Override
    public Employee getById(int id) {
        return employees.stream().filter(e -> e.getId() == id).findFirst().orElse(null);
    }

    @Override
    public List<Employee> getByName(String name) {
        return employees.stream().filter(e -> e.getName().equalsIgnoreCase(name)).collect(Collectors.toList());
    }

    @Override
    public List<Employee> getByDepartment(String dept) {
        return employees.stream().filter(e -> e.getDepartment().equalsIgnoreCase(dept)).collect(Collectors.toList());
    }

    @Override
    public List<Employee> getByDesignation(String desig) {
        return employees.stream().filter(e -> e.getDesignation().equalsIgnoreCase(desig)).collect(Collectors.toList());
    }

    @Override
    public List<Employee> getByType(String type) {
        return employees.stream()
                .filter(e -> e.getClass().getSimpleName().equalsIgnoreCase(type))
                .collect(Collectors.toList());
    }
}
