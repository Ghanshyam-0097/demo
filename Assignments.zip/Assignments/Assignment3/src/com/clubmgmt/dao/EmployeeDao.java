package com.clubmgmt.dao;

import com.clubmgmt.model.Employee;
import java.util.List;

public interface EmployeeDao {
    void addEmployee(Employee e);
    List<Employee> getAllEmployees();
    Employee getById(int id);
    List<Employee> getByName(String name);
    List<Employee> getByDepartment(String dept);
    List<Employee> getByDesignation(String desig);
    List<Employee> getByType(String type);
}
