package com.clubmgmt.dao;

import com.clubmgmt.model.Member;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class MemberDaoImpl implements MemberDao {
    private List<Member> members = new ArrayList<>();

    @Override
    public void addMember(Member m) {
        members.add(m);
    }

    @Override
    public List<Member> getAllMembers() {
        return members;
    }

    @Override
    public Member getById(int id) {
        return members.stream().filter(m -> m.getId() == id).findFirst().orElse(null);
    }

    @Override
    public List<Member> getByName(String name) {
        return members.stream().filter(m -> m.getName().equalsIgnoreCase(name)).collect(Collectors.toList());
    }
}
