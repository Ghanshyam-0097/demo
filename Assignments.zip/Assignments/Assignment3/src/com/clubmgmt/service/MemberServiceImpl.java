package com.clubmgmt.service;

import com.clubmgmt.dao.MemberDao;
import com.clubmgmt.dao.MemberDaoImpl;
import com.clubmgmt.model.Member;

import java.util.Scanner;

public class MemberServiceImpl implements MemberService {
    private MemberDao dao = new MemberDaoImpl();
    private Scanner sc = new Scanner(System.in);

    @Override
    public void addMember() {
        System.out.print("Enter name: ");
        String name = sc.nextLine();
        System.out.print("Enter mobile: ");
        String mobile = sc.nextLine();
        System.out.print("Enter email: ");
        String email = sc.nextLine();
        System.out.print("Enter membership type: ");
        String type = sc.nextLine();
        System.out.print("Enter amount paid: ");
        double amount = sc.nextDouble();
        sc.nextLine();

        Member m = new Member(name, mobile, email, type, amount);
        dao.addMember(m);
        System.out.println("Member added successfully.");
    }

    @Override
    public void viewAllMembers() {
        dao.getAllMembers().forEach(System.out::println);
    }

    @Override
    public void searchMemberById(int id) {
        Member m = dao.getById(id);
        if (m != null) System.out.println(m);
        else System.out.println("Member not found.");
    }

    @Override
    public void searchMemberByName(String name) {
        dao.getByName(name).forEach(System.out::println);
    }
}
