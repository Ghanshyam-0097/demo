package com.clubmgmt.service;

import com.clubmgmt.dao.EmployeeDao;
import com.clubmgmt.dao.EmployeeDaoImpl;
import com.clubmgmt.model.*;

public class ClubServiceImpl implements ClubService {
    private EmployeeDao employeeDao = new EmployeeDaoImpl();

    public void addDummyData() {
        employeeDao.addEmployee(new SalariedEmployee("Ghanshyam", "9999999999", "a@example.com", "HR", "Manager", "2020-01-01", 50000));
        employeeDao.addEmployee(new ContractEmployee("Sagar", "8888888888", "b@example.com", "IT", "Developer", "2021-06-10", 160, 500));
        employeeDao.addEmployee(new Vendor("DeveshS", "7777777777", "c@example.com", "Logistics", "Supplier", "2022-03-05", 5, 100000));
    }

    public void displayByType(String type) {
        employeeDao.getByType(type).forEach(System.out::println);
    }

    public void searchById(int id) {
        Employee e = employeeDao.getById(id);
        if (e != null) System.out.println(e);
        else System.out.println("Employee not found.");
    }

    public void searchByName(String name) {
        employeeDao.getByName(name).forEach(System.out::println);
    }

    public void displayAll() {
        employeeDao.getAllEmployees().forEach(System.out::println);
    }

    public void displayByDesignation(String designation) {
        employeeDao.getByDesignation(designation)
                .forEach(e -> System.out.println(e + ", Net Salary: " + e.calculateSalary()));
    }

    public void displayByDepartment(String dept) {
        employeeDao.getByDepartment(dept).stream().limit(5).forEach(System.out::println);
    }
}
