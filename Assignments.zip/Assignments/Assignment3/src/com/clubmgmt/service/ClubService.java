package com.clubmgmt.service;

public interface ClubService {
    void addDummyData();
    void displayByType(String type);
    void searchById(int id);
    void searchByName(String name);
    void displayAll();
    void displayByDesignation(String designation);
    void displayByDepartment(String dept);
}
