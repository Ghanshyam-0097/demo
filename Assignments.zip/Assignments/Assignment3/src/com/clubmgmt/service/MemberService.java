package com.clubmgmt.service;

public interface MemberService {
    void addMember();
    void viewAllMembers();
    void searchMemberById(int id);
    void searchMemberByName(String name);
}
