package com.clubmgmt.model;

public class Member {
    private static int idCounter = 200;
    private int id;
    private String name, mobile, email, membershipType;
    private double amountPaid;

    public Member(String name, String mobile, String email, String membershipType, double amountPaid) {
        this.id = idCounter++;
        this.name = name;
        this.mobile = mobile;
        this.email = email;
        this.membershipType = membershipType;
        this.amountPaid = amountPaid;
    }

    @Override
    public String toString() {
        return "Member ID: " + id + ", Name: " + name + ", Membership: " + membershipType + ", Amount: " + amountPaid;
    }

	public String getName() {
		return name;
	}

	public int getId() {
		return id;
	}

	
}
