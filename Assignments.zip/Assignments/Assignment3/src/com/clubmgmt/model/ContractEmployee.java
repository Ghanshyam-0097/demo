package com.clubmgmt.model;

public class ContractEmployee extends Employee {
    private int hoursWorked;
    private double rate;

    public ContractEmployee(String name, String mobile, String email, String department, String designation, String doj, int hoursWorked, double rate) {
        super(name, mobile, email, department, designation, doj);
        this.hoursWorked = hoursWorked;
        this.rate = rate;
    }

    @Override
    public double calculateSalary() {
        return hoursWorked * rate;
    }

    @Override
    public String toString() {
        return super.toString() + ", Type: Contract, Salary: " + calculateSalary();
    }
}
