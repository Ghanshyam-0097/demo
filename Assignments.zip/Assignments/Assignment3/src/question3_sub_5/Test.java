package question3_sub_5;

import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Java Test Questions
        Question[] javaQuestions = new Question[5];
        javaQuestions[0] = new Question(1, "What is the size of an int in Java?", "2 bytes", "4 bytes", "8 bytes", "16 bytes", 2, 1);
        javaQuestions[1] = new Question(2, "Which is a valid declaration of a boolean?", "boolean a = 1", "boolean a = true", "bool a = true", "boolean a = false", 2, 1);
        javaQuestions[2] = new Question(3, "Which of the following is not a primitive data type?", "int", "double", "boolean", "String", 4, 1);
        javaQuestions[3] = new Question(4, "Which method can be used to find the length of an array?", "size()", "length()", "lengthOf()", "getSize()", 2, 1);
        javaQuestions[4] = new Question(5, "Which keyword is used to define a class in Java?", "define", "class", "new", "object", 2, 1);

        // HTML Test Questions
        Question[] htmlQuestions = new Question[5];
        htmlQuestions[0] = new Question(1, "Which tag is used to define an unordered list?", "<ul>", "<ol>", "<li>", "<list>", 1, 1);
        htmlQuestions[1] = new Question(2, "Which tag is used for the largest heading?", "<h6>", "<h1>", "<h3>", "<h4>", 2, 1);
        htmlQuestions[2] = new Question(3, "What does HTML stand for?", "HyperText Markup Language", "Hyperlink Text Marking Language", "Home Tool Markup Language", "None of the above", 1, 1);
        htmlQuestions[3] = new Question(4, "Which HTML element is used to define a paragraph?", "<p>", "<div>", "<span>", "<section>", 1, 1);
        htmlQuestions[4] = new Question(5, "Which tag is used to display a horizontal line?", "<hr>", "<br>", "<line>", "<hl>", 1, 1);

        // Creating Exam Objects
        Exam javaExam = new Exam(101, "Java Test", "Java Programming", "2025-05-10", javaQuestions);
        Exam htmlExam = new Exam(102, "HTML Test", "HTML", "2025-05-12", htmlQuestions);

        // Main loop
        while (true) {
            System.out.println("Which exam would you like to appear for?");
            System.out.println("1. Java");
            System.out.println("2. HTML");
            System.out.print("Enter your choice (1/2): ");
            int choice = scanner.nextInt();

            int marks = 0;
            if (choice == 1) {
                System.out.println("\nYou selected Java Test!");
                marks = javaExam.conductTest();
            } else if (choice == 2) {
                System.out.println("\nYou selected HTML Test!");
                marks = htmlExam.conductTest();
            } else {
                System.out.println("Invalid choice! Please select 1 for Java or 2 for HTML.");
                continue;
            }

            System.out.println("\nYour total marks: " + marks + "/5");
            
            if (marks >= 3) {
                System.out.println("Congratulations! You completed the test.");
            } else {
                System.out.println("Better luck next time.");
            }

            System.out.print("\nDo you want to continue? (yes/no): ");
            String continueChoice = scanner.next().toLowerCase();
            if (!continueChoice.equals("yes")) {
                System.out.println("Thank you for taking the test! Goodbye.");
                break;
            }
        }

        scanner.close();
    }
}
