package question3_sub_5;

import java.util.Scanner;

class Exam {
    int examid;
    String name, topic, date;
    Question[] questions;

    public Exam(int examid, String name, String topic, String date, Question[] questions) {
        this.examid = examid;
        this.name = name;
        this.topic = topic;
        this.date = date;
        this.questions = questions;
    }
    public int conductTest() {
        Scanner scanner = new Scanner(System.in);
        int totalMarks = 0;

        for (Question q : questions) {
            System.out.println("Q" + q.qno + ": " + q.question);
            System.out.println("1. " + q.opt1);
            System.out.println("2. " + q.opt2);
            System.out.println("3. " + q.opt3);
            System.out.println("4. " + q.opt4);
            System.out.print("Enter your answer (1/2/3/4): ");
            int userAns = scanner.nextInt();

            if (userAns == q.ans) {
                totalMarks += q.marks;
            }
        }

        return totalMarks;
    }

    }