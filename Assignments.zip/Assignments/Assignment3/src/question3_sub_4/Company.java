package question3_sub_4;

import java.util.List;

class Company extends Customer {
    String relationshipManager;
    double creditLine;
    List<String> extensions;
    List<String> listOfNumbers;

    public Company(String custId, String name, String email, String creditClass, double discount,
                   String planAssigned, String relationshipManager, double creditLine,
                   List<String> extensions, List<String> listOfNumbers) {
        super(custId, name, email, creditClass, discount, planAssigned);
        this.relationshipManager = relationshipManager;
        this.creditLine = creditLine;
        this.extensions = extensions;
        this.listOfNumbers = listOfNumbers;
    }

    public void displayInfo() {
        System.out.println("Company Customer ID: " + custId);
        System.out.println("Company Name: " + name);
        System.out.println("Email: " + email);
        System.out.println("Credit Class: " + creditClass);
        System.out.println("Discount: " + discount);
        System.out.println("Plan Assigned: " + planAssigned);
        System.out.println("Relationship Manager: " + relationshipManager);
        System.out.println("Credit Line: " + creditLine);
        System.out.println("Extensions: " + extensions);
        System.out.println("List of Numbers: " + listOfNumbers);
    }
}
