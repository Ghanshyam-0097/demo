package question3_sub_4;
import java.util.*;

class Person {
    String name;
    String email;

 public Person(String name, String email) {
        this.name = name;
        this.email = email;
    }
}
