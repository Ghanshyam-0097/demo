package question3_sub_4;

class Individual extends Customer {
    String phoneNumber;

    public Individual(String custId, String name, String email, String creditClass, double discount,
                      String planAssigned, String phoneNumber) {
        super(custId, name, email, creditClass, discount, planAssigned);
        this.phoneNumber = phoneNumber;
    }

    public void displayInfo() {
        System.out.println("Individual Customer ID: " + custId);
        System.out.println("Name: " + name);
        System.out.println("Email: " + email);
        System.out.println("Credit Class: " + creditClass);
        System.out.println("Discount: " + discount);
        System.out.println("Plan Assigned: " + planAssigned);
        System.out.println("Phone Number: " + phoneNumber);
    }
}
