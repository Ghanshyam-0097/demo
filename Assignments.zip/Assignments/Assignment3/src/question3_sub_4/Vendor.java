package question3_sub_4;

import java.util.List;

class Vendor extends Person {
    String vendorId;
    String phoneNumber;
    List<String> products;

    public Vendor(String vendorId, String name, String email, String phoneNumber, List<String> products) {
        super(name, email);
        this.vendorId = vendorId;
        this.phoneNumber = phoneNumber;
        this.products = products;
    }

    public void displayInfo() {
        System.out.println("Vendor ID: " + vendorId);
        System.out.println("Name: " + name);
        System.out.println("Email: " + email);
        System.out.println("Phone: " + phoneNumber);
        System.out.println("Products: " + products);
    }
}
