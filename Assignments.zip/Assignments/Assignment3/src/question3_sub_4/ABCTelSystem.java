package question3_sub_4;

import java.util.Arrays;

public class ABCTelSystem {
    public static void main(String[] args) {
        // Sample Vendor
        Vendor vendor = new Vendor("V101", "Tech Supplies Inc.", "vendor@techsupplies.com", "9876543210",
                Arrays.asList("Routers", "Cables", "SIM Cards"));
        vendor.displayInfo();
        System.out.println();

        // Sample Individual Customer
        Individual individual = new Individual("C001", "John Doe", "john@example.com", "A", 10.5,
                "Prepaid", "9123456789");
        individual.displayInfo();
        System.out.println();

        // Sample Company Customer
        Company company = new Company("C002", "XYZ Corp", "contact@xyz.com", "B", 15.0,
                "Postpaid", "Alice Smith", 50000.0,
                Arrays.asList("101", "102", "103"),
                Arrays.asList("9001234567", "9001234568", "9001234569"));
        company.displayInfo();
    }
}
