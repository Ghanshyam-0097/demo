package question3_sub_4;
import java.util.*;

abstract class Customer extends Person {
    String custId;
    String creditClass;
    double discount;
    String planAssigned;

    public Customer(String custId, String name, String email, String creditClass, double discount, String planAssigned) {
        super(name, email);
        this.custId = custId;
        this.creditClass = creditClass;
        this.discount = discount;
        this.planAssigned = planAssigned;
    }

    abstract void displayInfo();
}