package com.example.annotations;

public class MyClass {
    @CustomAnnotation
    public void method1() {
        System.out.println("Method 1 is annotated and invoked.");
    }

    public void method2() {
        System.out.println("Method 2 is not annotated.");
    }

    @CustomAnnotation
    public void method3() {
        System.out.println("Method 3 is annotated and invoked.");
    }
}
