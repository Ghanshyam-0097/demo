package com.example.annotations;

import java.lang.reflect.Method;

public class Main {
    public static void main(String[] args) {
        MyClass myClass = new MyClass();
        Method[] methods = MyClass.class.getDeclaredMethods();

        for (Method method : methods) {
            if (method.isAnnotationPresent(CustomAnnotation.class)) {
                try {
                    method.invoke(myClass);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                System.out.println(method.getName() + " is not annotated.");
            }
        }
    }
}
