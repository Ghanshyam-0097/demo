package Studentcsv;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;


public class Test {
	public static void main(String[] args) {
        ArrayList<Student> studentList = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader("students.csv"))) {
            String line;
            boolean headerSkipped = false;

            while ((line = br.readLine()) != null) {
                if (!headerSkipped) {
                    headerSkipped = true; 
                    continue;
                }

                String[] parts = line.split(",");
                if (parts.length == 4) {
                    int id = Integer.parseInt(parts[0]);
                    String name = parts[1];
                    String degree = parts[2];
                    String email = parts[3];

                    Student s = new Student(id, name, degree, email);
                    studentList.add(s);
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }

        System.out.println("Student Information:");
        for (Student s : studentList) {
            s.display();
        }
    }
}

