package Default;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Student> studentList = new ArrayList<>();

        System.out.println("Enter student data (type 'exit' to finish):");

        while (true) {
            System.out.print("Enter Student ID (or type 'exit'): ");
            String input = sc.nextLine();
            if (input.equalsIgnoreCase("exit")) break;

            int id = Integer.parseInt(input);
            System.out.print("Enter Name: ");
            String name = sc.nextLine();
            System.out.print("Enter Degree: ");
            String degree = sc.nextLine();
            System.out.print("Enter Email: ");
            String email = sc.nextLine();

            studentList.add(new Student(id, name, degree, email));
        }

        // Write to file using ObjectOutputStream
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("students.dat"))) {
            oos.writeObject(studentList);
            System.out.println("Student data saved to students.dat");
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }

        sc.close();
    }
}

