package Student;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Test {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<student> studentList = new ArrayList<>();

        System.out.println("Enter student data (type 'exit' to finish):");

        while (true) {
            System.out.print("Enter Student ID (or type 'exit'): ");
            String input = sc.nextLine();
            if (input.equalsIgnoreCase("exit")) break;

            int id = Integer.parseInt(input);
            System.out.print("Enter Name: ");
            String name = sc.nextLine();
            System.out.print("Enter Degree: ");
            String degree = sc.nextLine();
            System.out.print("Enter Email: ");
            String email = sc.nextLine();

            studentList.add(new student(id, name, degree, email));
        }

        
        try (FileWriter writer = new FileWriter("students.csv")) {
            writer.write("ID,Name,Degree,Email\n"); 
            for (student s : studentList) {
                writer.write(s.toCSV() + "\n");
            }
            System.out.println("Student data saved to students.csv");
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }

        sc.close();
    }
}
