package reflection;

public class MyClass {
    public void method5(String a, int b, double c, boolean d) {}
    public void method6(String name, int id, float salary, char grade) {}
}