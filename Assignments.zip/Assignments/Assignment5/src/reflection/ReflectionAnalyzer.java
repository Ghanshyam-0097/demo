package reflection;

import java.lang.reflect.*;

public class ReflectionAnalyzer {
    public static void analyzeClass(Class<?> clazz) {
        System.out.println("Class: " + clazz.getName());

        for (Method method : clazz.getDeclaredMethods()) {
            System.out.println("  Method: " + method.getName());
            Parameter[] parameters = method.getParameters();
            System.out.println("    Parameter Count: " + parameters.length);
            for (Parameter param : parameters) {
                System.out.println("    Parameter: " + param.getName() + ", Type: " + param.getType().getSimpleName());
            }

            if (parameters.length >= 3) {
                try {
                    System.out.println("    Invoking method " + method.getName());
                } catch (Exception e) {
                    System.out.println("    Could not invoke method: " + e.getMessage());
                }
            }
        }
    }

    public static void main(String[] args) {
        analyzeClass(Rectangle.class);
        analyzeClass(Student.class);
        analyzeClass(Friend.class);
        analyzeClass(MyClass.class);
    }
}