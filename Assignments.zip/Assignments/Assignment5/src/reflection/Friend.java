package reflection;

public class Friend {
    public void sendMessage(String message, int time, String sender) {}
    public void receiveMessage(String message) {}
}