package reflection;

public class Student {
    public void setDetails(String name, int age, String course) {}
    public String getDetails() { return ""; }
}