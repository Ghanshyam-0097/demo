package reflection;

public class Rectangle {
    public void setDimensions(int length, int width) {}
    public int getArea() { return 0; }
}